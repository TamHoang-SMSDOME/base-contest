delete from BC_240501_COKENCP_Retailer

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (0, '', '- Select One -', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (1, 'Cold Storage', 'Cold Storage', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (2, 'CS Fresh', 'CS Fresh', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (3, 'Giant', 'Giant', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (4, 'NTUC FairPrice', 'NTUC FairPrice', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (5, 'Prime', 'Prime', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (6, 'Sheng Siong', 'Sheng Siong', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (7, 'ACE Mart', 'ACE Mart', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (8, 'HAO Mart', 'HAO Mart', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (9, 'New Econ', 'New Econ', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (10, 'One Supermarket', 'One Supermarket', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (11, 'U-Stars', 'U-Stars', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (12, 'Caltex', 'Caltex', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (13, 'Cheers', 'Cheers', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (14, 'FairPrice Xpress', 'FairPrice Xpress', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (15, 'Shell', 'Shell', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (16, 'Sinopec', 'Sinopec', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (17, 'SPC', 'SPC', 1);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (18, 'Canadian 2-for-1 Pizza', 'Canadian 2-for-1 Pizza', 0);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (19, 'Aji/Tempura Bar', 'Aji/Tempura Bar', 0);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (20, 'East Treasure Chinese restaurant', 'East Treasure Chinese restaurant', 0);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (21, 'Bizen', 'Bizen', 0);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (22, 'The Ranch', 'The Ranch', 0);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (23, 'Mandai Wildlife Group - Zoo/Bird Paradise', 'Mandai Wildlife Group - Zoo/Bird Paradise', 0);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (24, 'Mount Faber Retail', 'Mount Faber Retail', 0);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (25, 'Mount Faber F&B', 'Mount Faber F&B', 0);

INSERT INTO BC_240501_COKENCP_Retailer([ID], [Code], [Text], [HaveMinSpend])
VALUES (26, 'Burger King', 'Burger King', 0);




